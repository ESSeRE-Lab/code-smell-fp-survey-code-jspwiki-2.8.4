/**
 ** Skin javascript extensions
 **
 **/

/*  
if( RoundedCorners )
{  
  var r = RoundedCorners;
  r.register( "#header",    ['bbbb', 'eee', 'ddd' ] );
  r.register( "#footer",    ['bbbb', 'eee', 'ddd' ] );

  r.register( "#favorites", ['yyyy', 'eee', 'ddd'] );

  r.register( ".commentbox",['yyyy', 'transparent', 'ddd'] );
  r.register( ".tabmenu a", ['yynn', 'transparent', 'ddd'] );

}
*/ 