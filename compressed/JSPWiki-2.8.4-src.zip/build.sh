#!/bin/sh

ant -Dbuild.properties=build.properties -find
